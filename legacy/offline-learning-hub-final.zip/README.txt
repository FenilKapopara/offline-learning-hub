﻿Offline Learning Hub – Learner + Tutor Pages (Final Version)

Files
- index.html → Learner page
- app.js → Learner logic
- tutor.html → Tutor upload page
- tutor.js → Tutor logic
- README.txt → Setup instructions

How to use
1. Open index.html (Learner) or tutor.html (Tutor) in your browser.
2. Works offline; uploads list is stored in your browser (demo mode).

Optional local server:
python -m http.server 5173
# open http://localhost:5173/index.html
