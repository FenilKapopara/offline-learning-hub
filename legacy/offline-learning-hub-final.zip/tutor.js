﻿// Tutor upload and listing logic
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const msg = document.getElementById('uploadMsg');
const uploads = document.getElementById('uploads');

uploadBtn.onclick = () => {
  const f = fileInput.files[0];
  if(!f){ msg.textContent='Please select a file first.'; return; }
  const list = JSON.parse(localStorage.getItem('uploads')||'[]');
  const item = {name:f.name, size:f.size, ts:Date.now()};
  list.push(item);
  localStorage.setItem('uploads', JSON.stringify(list));
  msg.textContent = 'Uploaded locally (demo mode).';
  render();
};

function render(){
  const list = JSON.parse(localStorage.getItem('uploads')||'[]');
  if(list.length===0){ uploads.innerHTML='<p>No uploads yet.</p>'; return; }
  uploads.innerHTML = list.map(x=><div class='p-3 border bg-white rounded'>
    <div class='font-semibold'></div>
    <div class='text-xs text-gray-600'> KB • </div>
  </div>).join('');
}
render();
