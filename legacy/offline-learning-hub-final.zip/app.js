﻿// Sample learner script
const courses = [
  {id:'c1', title:'Basic Reading', subject:'Literacy'},
  {id:'c2', title:'Everyday Math', subject:'Math'}
];

const container = document.getElementById('courses');
container.innerHTML = courses.map(c=>
  <div class='p-4 border rounded bg-white'>
    <div class='font-semibold'></div>
    <div class='text-sm text-gray-600'></div>
  </div>
).join('');
